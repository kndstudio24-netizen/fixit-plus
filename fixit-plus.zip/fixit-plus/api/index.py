import os, re, random, sqlite3
from collections import Counter
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, jsonify, request, g
from itsdangerous import URLSafeTimedSerializer
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
ser = URLSafeTimedSerializer(os.environ.get("SECRET_KEY", "dev-secret-change-me"))
DB = "/tmp/fixit.db" if os.environ.get("VERCEL") else os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixit.db")
SLA = {"CRITICAL": 1, "HIGH": 2, "MEDIUM": 6, "LOW": 24}
STATUSES = ["Pending", "Assigned", "In Progress", "Resolved", "Reopened"]
KW = {
 "Electrical": ["socket", "spark", "wire", "electric", "power", "switch", "fan", "light", "bulb", "shock", "burnt", "short circuit"],
 "Plumbing": ["leak", "tap", "water", "pipe", "drain", "toilet", "flush", "overflow", "flood"],
 "Furniture": ["bench", "desk", "chair", "table", "door", "cupboard"],
 "Internet": ["wifi", "internet", "network", "router", "lan"],
 "Equipment": ["projector", "computer", "microscope", "equipment", "board", "ac "],
 "Cleanliness": ["dirty", "garbage", "trash", "smell", "clean", "dustbin"],
 "Safety": ["fire", "smoke", "hazard", "unsafe", "injury", "gas", "extinguisher"],
 "Civil": ["crack", "ceiling", "wall", "roof", "floor", "paint", "stair"]}
DANGER = ["spark", "burnt", "smoke", "fire", "shock", "gas", "exposed wire", "short circuit", "flood", "collapse"]
HIGHLOC = ["lab", "hostel", "library", "canteen", "auditorium", "mess"]
DEPT = {"Electrical": "Electrical", "Plumbing": "Plumbing", "Furniture": "Furniture", "Internet": "Network"}
STOP = set("a an the is are in on at of to and not it this that for with from near".split())

def now(): return datetime.utcnow().replace(microsecond=0)
def err(m, c=400): return jsonify({"success": False, "message": m}), c

# ---------- "MAJJAA AI": transparent keyword + rules engine ----------
def analyze(text, cat=None):
    t = text.lower() + " "
    sc = {c: sum(1 for k in ks if k in t) for c, ks in KW.items()}
    best = max(sc, key=sc.get)
    pred = best if sc[best] > 0 else "Other"
    conf = min(0.98, 0.6 + 0.12 * sc[best]) if sc[best] > 0 else 0.3
    category = cat if cat in KW or cat == "Other" else pred
    danger = [d for d in DANGER if d in t]
    sev = 2 + 2 * len(danger) + (1 if re.search(r"not working|broken|leak|stopped|damaged|missing", t) else 0)
    if category == "Safety": sev += 1
    sev = min(5, sev)
    loc = 3 if any(h in t for h in HIGHLOC) else 2
    score = sev * loc + (6 if danger else 0)
    pr = "LOW" if score <= 5 else "MEDIUM" if score <= 12 else "HIGH" if score <= 20 else "CRITICAL"
    reasons = []
    if danger: reasons += ["Safety hazard keywords detected: " + ", ".join(danger), "Immediate attention recommended"]
    if loc == 3: reasons.append("High-impact location (lab/hostel/library/etc.)")
    reasons.append(f"Score = severity {sev} x location {loc}" + (" + safety bonus 6" if danger else "") + f" = {score}")
    return {"category": category, "predicted_category": pred, "confidence": round(conf, 2), "severity": sev,
            "priority": pr, "priority_score": score, "department": DEPT.get(category, "General") + " Maintenance",
            "sla_hours": SLA[pr], "reasons": reasons}

def toks(s):
    out = []
    for w in re.findall(r"[a-z0-9]+", s.lower()):
        if w in STOP: continue
        for suf in ("ing", "s"):
            if w.endswith(suf) and len(w) > 4: w = w[:-len(suf)]
        out.append(w)
    return Counter(out)

def cosine(a, b):
    dot = sum(a[k] * b[k] for k in a)
    na, nb = sum(v * v for v in a.values()) ** .5, sum(v * v for v in b.values()) ** .5
    return dot / (na * nb) if na and nb else 0

# ---------- database ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db
@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()
def q(sql, a=(), one=False):
    c = db().execute(sql, a); r = c.fetchall(); db().commit()
    return (r[0] if r else None) if one else r

SCHEMA = """
create table users(id integer primary key, name text, email text unique, password_hash text, role text, department text, created_at text);
create table issues(id integer primary key, ticket_id text, title text, description text, category text, building text, room text,
 priority text, ai_priority text, severity int, priority_score int, status text, reported_by int, assigned_to int, ai_confidence real,
 confirmed int default 0, created_at text, updated_at text, resolved_at text, sla_deadline text);
create table comments(id integer primary key, issue_id int, user_id int, comment text, created_at text);
create table evidence(id integer primary key, issue_id int, description text, uploaded_by int, uploaded_at text);
create table notifications(id integer primary key, user_id int, issue_id int, message text, is_read int default 0, created_at text);
create table history(id integer primary key, issue_id int, changed_by int, old_status text, new_status text, timestamp text);
"""
def new_issue(c, title, desc, cat, building, room, uid, ts=None):
    a = analyze(f"{title} {desc} {room}", cat)
    ts = ts or now()
    n = c.execute("select count(*) from issues").fetchone()[0]
    cur = c.execute("insert into issues(ticket_id,title,description,category,building,room,priority,ai_priority,severity,priority_score,status,reported_by,ai_confidence,created_at,updated_at,sla_deadline) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (f"FX-{1001+n}", title, desc, a["category"], building, room, a["priority"], a["priority"], a["severity"], a["priority_score"], "Pending", uid, a["confidence"],
         ts.isoformat(), ts.isoformat(), (ts + timedelta(hours=a["sla_hours"])).isoformat()))
    c.execute("insert into history(issue_id,changed_by,old_status,new_status,timestamp) values(?,?,?,?,?)", (cur.lastrowid, uid, None, "Pending", ts.isoformat()))
    return cur.lastrowid, a

def seed():
    c = sqlite3.connect(DB); c.executescript(SCHEMA)
    pw = generate_password_hash("fixit123"); t = now().isoformat()
    users = [("Demo Admin", "admin@fixit.com", "admin", "Administration"), ("Ravi (Electrical)", "staff@fixit.com", "staff", "Electrical"),
             ("Meena (Plumbing)", "plumber@fixit.com", "staff", "Plumbing"), ("Suresh (Furniture)", "carpenter@fixit.com", "staff", "Furniture"),
             ("Anand (Network)", "network@fixit.com", "staff", "Network"), ("Lakshmi (General)", "general@fixit.com", "staff", "General"),
             ("Demo Student", "student@fixit.com", "student", "CSE")]
    first = ["Arun", "Divya", "Karthik", "Priya", "Vikram", "Sneha", "Rahul", "Nisha", "Ganesh", "Pooja", "Harish", "Keerthi", "Manoj", "Swathi", "Naveen", "Deepa", "Bala", "Revathi", "Dinesh"]
    users += [(f"{n} {chr(65 + i % 8)}.", f"student{i + 1}@fixit.com", "student", random.choice(["CSE", "ECE", "MECH", "EEE", "CIVIL"])) for i, n in enumerate(first)]
    for u in users: c.execute("insert into users(name,email,password_hash,role,department,created_at) values(?,?,?,?,?,?)", (u[0], u[1], pw, u[2], u[3], t))
    random.seed(7)
    T = [("Power socket sparking", "Power socket in Lab 3 is sparking and smells burnt", "Block A", "Lab 3"),
         ("Ceiling fan not working", "Ceiling fan stopped working in room", "Block B", "204"), ("Tap leaking", "Water leakage from tap in washroom", "Block C", "Washroom 1"),
         ("Broken bench", "Bench broken in classroom, unsafe to sit", "Block B", "110"), ("WiFi down", "WiFi not working in reading hall", "Library", "Reading Hall"),
         ("Projector faulty", "Projector not turning on in classroom", "Block D", "301"), ("Garbage overflow", "Dustbins overflowing with garbage and bad smell", "Hostel", "Mess"),
         ("Wall crack", "Crack in wall near staircase", "Block A", "Stairs"), ("Light flickering", "Tube light flickering and buzzing", "Block C", "105"),
         ("Pipe overflow", "Water pipe overflow flooding corridor", "Hostel", "Floor 2"), ("Microscope damaged", "Lab equipment microscope lens damaged", "Block A", "Lab 2"),
         ("Extinguisher missing", "Fire extinguisher missing, safety hazard", "Block D", "Corridor")]
    sid = {r[0]: r[1] for r in c.execute("select department,id from users where role='staff'")}
    students = [r[0] for r in c.execute("select id from users where role='student'")]
    for _ in range(50):
        tp = random.choice(T); ts = now() - timedelta(hours=random.randint(1, 720))
        iid, a = new_issue(c, tp[0], tp[1], None, tp[2], tp[3], random.choice(students), ts)
        st = random.choices(STATUSES[:4], [2, 2, 2, 5])[0]
        if st == "Pending": continue
        stf = sid.get(DEPT.get(a["category"], "General"), sid["General"])
        t1 = ts + timedelta(minutes=random.randint(3, 40))
        c.execute("update issues set assigned_to=?,status='Assigned',updated_at=? where id=?", (stf, t1.isoformat(), iid))
        c.execute("insert into history(issue_id,changed_by,old_status,new_status,timestamp) values(?,?,?,?,?)", (iid, 1, "Pending", "Assigned", t1.isoformat()))
        last = t1
        for s in STATUSES[2:STATUSES.index(st) + 1]:
            last = last + timedelta(hours=random.uniform(0.2, a["sla_hours"] * 1.6))
            c.execute("insert into history(issue_id,changed_by,old_status,new_status,timestamp) values(?,?,?,?,?)", (iid, stf, None, s, last.isoformat()))
            c.execute("update issues set status=?,updated_at=? where id=?", (s, last.isoformat(), iid))
        if st == "Resolved":
            c.execute("update issues set resolved_at=?,confirmed=? where id=?", (last.isoformat(), random.randint(0, 1), iid))
            c.execute("insert into evidence(issue_id,description,uploaded_by,uploaded_at) values(?,?,?,?)", (iid, "Issue fixed and tested.", stf, last.isoformat()))
    c.commit(); c.close()

if not os.path.exists(DB): seed()

# ---------- helpers ----------
def auth(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            try: uid = ser.loads(request.headers.get("Authorization", "").replace("Bearer ", ""), max_age=172800)
            except Exception: return err("Please log in again.", 401)
            u = q("select * from users where id=?", (uid,), one=True)
            if not u: return err("Please log in again.", 401)
            if roles and u["role"] not in roles: return err("You do not have permission to do that.", 403)
            g.user = u; return f(*a, **k)
        return w
    return deco

BASE = "select i.*, r.name reporter, a.name assignee from issues i left join users r on r.id=i.reported_by left join users a on a.id=i.assigned_to"
def fmt(r):
    d = dict(r); end = datetime.fromisoformat(d["resolved_at"]) if d["resolved_at"] else now()
    d["breached"] = end > datetime.fromisoformat(d["sla_deadline"]); return d
def notify(uid, iid, msg): q("insert into notifications(user_id,issue_id,message,created_at) values(?,?,?,?)", (uid, iid, msg, now().isoformat()))
def body(): return request.get_json(silent=True) or {}

def set_status(i, new, by, note=None):
    ts = now().isoformat()
    res = ts if new == "Resolved" else None if new == "Reopened" else i["resolved_at"]
    q("update issues set status=?,updated_at=?,resolved_at=?,confirmed=0 where id=?", (new, ts, res, i["id"]))
    q("insert into history(issue_id,changed_by,old_status,new_status,timestamp) values(?,?,?,?,?)", (i["id"], by, i["status"], new, ts))
    if new == "Resolved" and note: q("insert into evidence(issue_id,description,uploaded_by,uploaded_at) values(?,?,?,?)", (i["id"], note, by, ts))
    msg = {"In Progress": f"Maintenance staff has started working on {i['ticket_id']}.", "Resolved": f"Your issue {i['ticket_id']} has been resolved. Please confirm.",
           "Assigned": f"Your issue {i['ticket_id']} has been assigned."}.get(new, f"{i['ticket_id']} is now {new}.")
    notify(i["reported_by"], i["id"], msg)
    if new == "Reopened":
        for a in q("select id from users where role='admin'"): notify(a["id"], i["id"], f"{i['ticket_id']} was reopened by the reporter.")

# ---------- routes ----------
@app.route("/api/login", methods=["POST"])
def login():
    b = body(); u = q("select * from users where email=?", ((b.get("email") or "").strip().lower(),), one=True)
    if not u or not check_password_hash(u["password_hash"], b.get("password") or ""): return err("Incorrect email or password.", 401)
    return jsonify({"success": True, "token": ser.dumps(u["id"]), "user": {k: u[k] for k in ("id", "name", "email", "role", "department")}})

@app.route("/api/public-stats")
def public_stats():
    rows = [fmt(r) for r in q(BASE)]; res = [r for r in rows if r["resolved_at"]]
    avg = sum((datetime.fromisoformat(r["resolved_at"]) - datetime.fromisoformat(r["created_at"])).total_seconds() for r in res) / 3600 / len(res) if res else 0
    return jsonify({"total": len(rows), "resolved": len(res), "active": len(rows) - len(res), "avg_hours": round(avg, 1)})

@app.route("/api/ai/analyze", methods=["POST"])
@auth()
def ai_analyze():
    b = body()
    if not (b.get("description") or "").strip(): return err("Issue description is required.")
    return jsonify({"success": True, **analyze(f"{b.get('title', '')} {b['description']} {b.get('room', '')}", b.get("category"))})

@app.route("/api/ai/duplicate-check", methods=["POST"])
@auth()
def dup():
    b = body(); new = toks(f"{b.get('title', '')} {b.get('description', '')} {b.get('room', '')}"); best = None
    for r in q("select * from issues where status!='Resolved'"):
        if b.get("building") and r["building"] != b["building"]: continue
        s = cosine(new, toks(f"{r['title']} {r['description']} {r['room']}"))
        if s > 0.6 and (not best or s > best["similarity"]): best = {"similarity": round(s, 2), "id": r["id"], "ticket_id": r["ticket_id"], "status": r["status"], "title": r["title"]}
    return jsonify({"success": True, "duplicate": best})

@app.route("/api/issues", methods=["POST"])
@auth("student", "admin")
def create_issue():
    b = body(); t, d, bl = (b.get("title") or "").strip(), (b.get("description") or "").strip(), (b.get("building") or "").strip()
    if not t or not d or not bl: return err("Title, description and building are required.")
    if len(t) > 120 or len(d) > 2000: return err("Title or description is too long.")
    c = sqlite3.connect(DB); iid, a = new_issue(c, t, d, b.get("category"), bl, (b.get("room") or "")[:60], g.user["id"]); c.commit(); c.close()
    for ad in q("select id from users where role='admin'"): notify(ad["id"], iid, f"New {a['priority']} issue reported: {t}")
    return jsonify({"success": True, "id": iid, "ticket_id": q("select ticket_id from issues where id=?", (iid,), one=True)[0]})

@app.route("/api/issues")
@auth()
def list_issues():
    w, a = [], []
    u = g.user
    if u["role"] == "student": w.append("i.reported_by=?"); a.append(u["id"])
    if u["role"] == "staff": w.append("i.assigned_to=?"); a.append(u["id"])
    for k in ("category", "priority", "status", "building"):
        if request.args.get(k): w.append(f"i.{k}=?"); a.append(request.args[k])
    if request.args.get("assigned_to"): w.append("i.assigned_to=?"); a.append(request.args["assigned_to"])
    if request.args.get("q"):
        s = f"%{request.args['q']}%"; w.append("(i.ticket_id like ? or i.title like ? or i.description like ? or i.room like ?)"); a += [s] * 4
    sql = BASE + (" where " + " and ".join(w) if w else "") + " order by case i.priority when 'CRITICAL' then 0 when 'HIGH' then 1 when 'MEDIUM' then 2 else 3 end, i.created_at desc"
    return jsonify({"success": True, "issues": [fmt(r) for r in q(sql, a)]})

def can_see(i):
    u = g.user; return u["role"] == "admin" or i["reported_by"] == u["id"] or i["assigned_to"] == u["id"]

@app.route("/api/issues/<int:iid>")
@auth()
def get_issue(iid):
    r = q(BASE + " where i.id=?", (iid,), one=True)
    if not r or not can_see(r): return err("Issue not found.", 404)
    L = lambda s: [dict(x) for x in q(s, (iid,))]
    return jsonify({"success": True, "issue": fmt(r),
        "comments": L("select c.*, u.name from comments c join users u on u.id=c.user_id where issue_id=? order by c.id"),
        "history": L("select h.*, u.name from history h left join users u on u.id=h.changed_by where issue_id=? order by h.id"),
        "evidence": L("select e.*, u.name from evidence e left join users u on u.id=e.uploaded_by where issue_id=?")})

@app.route("/api/issues/<int:iid>", methods=["PUT"])
@auth("admin")
def edit_issue(iid):
    p = body().get("priority")
    if p not in SLA: return err("Priority must be LOW, MEDIUM, HIGH or CRITICAL.")
    i = q("select * from issues where id=?", (iid,), one=True)
    if not i: return err("Issue not found.", 404)
    q("update issues set priority=?, sla_deadline=? where id=?", (p, (datetime.fromisoformat(i["created_at"]) + timedelta(hours=SLA[p])).isoformat(), iid))
    return jsonify({"success": True})

@app.route("/api/issues/<int:iid>", methods=["DELETE"])
@auth("admin")
def del_issue(iid):
    for t in ("comments", "evidence", "notifications", "history"): q(f"delete from {t} where issue_id=?", (iid,))
    q("delete from issues where id=?", (iid,)); return jsonify({"success": True})

@app.route("/api/staff")
@auth("admin")
def staff(): return jsonify({"success": True, "staff": [dict(r) for r in q("select id,name,department from users where role='staff'")]})

@app.route("/api/issues/<int:iid>/assign", methods=["POST"])
@auth("admin")
def assign(iid):
    i = q("select * from issues where id=?", (iid,), one=True); s = q("select * from users where id=? and role='staff'", (body().get("staff_id"),), one=True)
    if not i or not s: return err("Issue or staff member not found.", 404)
    q("update issues set assigned_to=? where id=?", (s["id"], iid))
    if i["status"] in ("Pending", "Reopened"): set_status(i, "Assigned", g.user["id"])
    notify(s["id"], iid, f"You have been assigned {i['ticket_id']}: {i['title']}")
    return jsonify({"success": True})

@app.route("/api/issues/<int:iid>/status", methods=["PUT"])
@auth()
def status(iid):
    b = body(); new = b.get("status"); u = g.user; i = q("select * from issues where id=?", (iid,), one=True)
    if new not in STATUSES: return err("Invalid status.")
    if not i or not can_see(i): return err("Issue not found.", 404)
    note = (b.get("note") or "").strip()
    if u["role"] == "staff":
        if new not in ("In Progress", "Resolved") or i["assigned_to"] != u["id"]: return err("Staff can only start or resolve their own tasks.", 403)
        if new == "Resolved" and not note: return err("Please describe the work done before resolving.")
    if u["role"] == "student" and not (new == "Reopened" and i["status"] == "Resolved" and i["reported_by"] == u["id"]): return err("You can only reopen your own resolved issues.", 403)
    set_status(i, new, u["id"], note); return jsonify({"success": True})

@app.route("/api/issues/<int:iid>/confirm", methods=["POST"])
@auth("student")
def confirm(iid):
    i = q("select * from issues where id=? and reported_by=? and status='Resolved'", (iid, g.user["id"]), one=True)
    if not i: return err("Only your resolved issues can be confirmed.", 404)
    q("update issues set confirmed=1 where id=?", (iid,)); return jsonify({"success": True})

@app.route("/api/issues/<int:iid>/comments", methods=["GET", "POST"])
@auth()
def comments(iid):
    i = q("select * from issues where id=?", (iid,), one=True)
    if not i or not can_see(i): return err("Issue not found.", 404)
    if request.method == "POST":
        c = (body().get("comment") or "").strip()
        if not c: return err("Comment cannot be empty.")
        q("insert into comments(issue_id,user_id,comment,created_at) values(?,?,?,?)", (iid, g.user["id"], c[:1000], now().isoformat()))
        return jsonify({"success": True})
    return jsonify({"success": True, "comments": [dict(x) for x in q("select c.*,u.name from comments c join users u on u.id=c.user_id where issue_id=?", (iid,))]})

@app.route("/api/notifications")
@auth()
def notifs():
    r = [dict(x) for x in q("select * from notifications where user_id=? order by id desc limit 30", (g.user["id"],))]
    return jsonify({"success": True, "notifications": r, "unread": sum(1 for x in r if not x["is_read"])})

@app.route("/api/notifications/<int:nid>/read", methods=["PUT"])
@auth()
def read(nid): q("update notifications set is_read=1 where id=? and user_id=?", (nid, g.user["id"])); return jsonify({"success": True})

@app.route("/api/analytics")
@auth("admin")
def analytics():
    rows = [fmt(r) for r in q(BASE)]; n = len(rows); res = [r for r in rows if r["resolved_at"]]
    hrs = lambda r: (datetime.fromisoformat(r["resolved_at"]) - datetime.fromisoformat(r["created_at"])).total_seconds() / 3600
    avg = lambda L: round(sum(L) / len(L), 1) if L else 0
    cnt = lambda k: dict(Counter(r[k] for r in rows))
    ok = [r for r in res if not r["breached"]]
    summary = {"total": n, "critical": sum(1 for r in rows if r["priority"] == "CRITICAL" and r["status"] != "Resolved"), "pending": sum(1 for r in rows if r["status"] in ("Pending", "Reopened")),
               "in_progress": sum(1 for r in rows if r["status"] in ("Assigned", "In Progress")), "resolved": len(res), "breached": sum(1 for r in rows if r["breached"] and r["status"] != "Resolved"),
               "resolution_rate": round(100 * len(res) / n, 1) if n else 0, "avg_hours": avg([hrs(r) for r in res]), "sla_compliance": round(100 * len(ok) / len(res), 1) if res else 0}
    bld = {}
    for b in sorted({r["building"] for r in rows}):
        x = [r for r in rows if r["building"] == b]; rs = [r for r in x if r["resolved_at"]]
        bld[b] = {"total": len(x), "critical": sum(1 for r in x if r["priority"] == "CRITICAL"), "top_category": Counter(r["category"] for r in x).most_common(1)[0][0], "avg_hours": avg([hrs(r) for r in rs])}
    perf = []
    for s in q("select id,name,department from users where role='staff'"):
        x = [r for r in rows if r["assigned_to"] == s["id"]]; rs = [r for r in x if r["resolved_at"]]
        perf.append({"name": s["name"], "department": s["department"], "assigned": len(x), "completed": len(rs), "open": len(x) - len(rs), "avg_hours": avg([hrs(r) for r in rs]),
                     "sla": round(100 * sum(1 for r in rs if not r["breached"]) / len(rs)) if rs else None})
    ins, nw = [], now()
    if rows:
        c, b = Counter(r["category"] for r in rows).most_common(1)[0], Counter(r["building"] for r in rows).most_common(1)[0]
        ins += [f"{c[0]} is the most reported category ({c[1]} of {n} issues).", f"{b[0]} has the most maintenance complaints ({b[1]})."]
        by = {}
        for r in res: by.setdefault(r["category"], []).append(hrs(r))
        if by: k = max(by, key=lambda x: sum(by[x]) / len(by[x])); ins.append(f"{k} issues take the longest to resolve (avg {avg(by[k])} h).")
        if res: ins.append(f"{summary['sla_compliance']}% of resolved issues were fixed within SLA.")
        inc = []
        for cat in {r["category"] for r in rows}:
            a1 = sum(1 for r in rows if r["category"] == cat and nw - datetime.fromisoformat(r["created_at"]) <= timedelta(days=15))
            a0 = sum(1 for r in rows if r["category"] == cat and timedelta(days=15) < nw - datetime.fromisoformat(r["created_at"]) <= timedelta(days=30))
            if a0 and a1 > a0: inc.append((round(100 * (a1 - a0) / a0), cat))
        if inc: p, cat = max(inc); ins.append(f"{cat} issues rose {p}% in the last 15 days compared with the 15 days before.")
    trend = dict(sorted(Counter(r["created_at"][:10] for r in rows).items())[-14:])
    return jsonify({"success": True, "summary": summary, "categories": cnt("category"), "priorities": cnt("priority"), "statuses": cnt("status"), "buildings": bld, "trends": trend, "insights": ins, "staff": perf})

@app.errorhandler(404)
def nf(_): return err("Resource not found.", 404)
@app.errorhandler(500)
def se(_): return err("Something went wrong on the server.", 500)

if __name__ == "__main__": app.run(debug=True, port=5000)

# FixIt+ — Report. Resolve. Improve.
Campus maintenance platform: React + Vite frontend, Flask API (Vercel serverless), SQLite, rule-based "MAJJAA AI".

## Run locally
```bash
pip install -r requirements.txt && python api/index.py   # terminal 1 (port 5000)
npm install && npm run dev                                # terminal 2 -> http://localhost:5173
```
Demo logins (password `fixit123`): student@fixit.com, admin@fixit.com, staff@fixit.com

## Deploy
1. `git init && git add . && git commit -m "FixIt+" ` then push to a new GitHub repo.
2. vercel.com -> Add New Project -> import the repo -> Deploy (framework: Vite, no config needed).
3. Optional env var: `SECRET_KEY` (any long random string).

Note: on Vercel the SQLite file lives in /tmp, so data resets on cold starts and re-seeds demo data. For permanent data, swap in a hosted Postgres.

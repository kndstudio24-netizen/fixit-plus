import {useState,useEffect,useCallback,createContext,useContext} from "react";
import {BrowserRouter,Routes,Route,Link,Navigate,useNavigate,useParams} from "react-router-dom";

const Auth=createContext();const useAuth=()=>useContext(Auth);
async function api(path,opt={}){
  const r=await fetch("/api"+path,{method:opt.method||"GET",headers:{"Content-Type":"application/json",Authorization:"Bearer "+(localStorage.getItem("t")||"")},body:opt.body?JSON.stringify(opt.body):undefined});
  let d={};try{d=await r.json()}catch{}
  if(!r.ok){if(r.status===401&&path!=="/login"){localStorage.clear();location.href="/login"}throw new Error(d.message||"Something went wrong. Please try again.")}
  return d;
}
function useLoad(path){
  const [d,setD]=useState(null),[e,setE]=useState("");
  const load=useCallback(()=>api(path).then(setD).catch(x=>setE(x.message)),[path]);
  useEffect(()=>{load()},[load]);return [d,e,load];
}
const ICONS={Electrical:"⚡",Plumbing:"🚿",Furniture:"🪑",Internet:"📶",Equipment:"🖥️",Cleanliness:"🧹",Safety:"🦺",Civil:"🏗️",Other:"📦"};
const CATS=Object.keys(ICONS),BUILDINGS=["Block A","Block B","Block C","Block D","Library","Hostel"],PRI=["CRITICAL","HIGH","MEDIUM","LOW"],STAT=["Pending","Assigned","In Progress","Resolved","Reopened"];
const fd=s=>s?new Date(s+"Z").toLocaleString():"—";
const P=({p})=><span className={"badge "+p}>{p}</span>;
const S=({s})=><span className="badge st">{s}</span>;
function SLA({i}){
  const [n,setN]=useState(Date.now());
  useEffect(()=>{const t=setInterval(()=>setN(Date.now()),1000);return()=>clearInterval(t)},[]);
  if(i.status==="Resolved")return <span>{i.breached?"🔴 Resolved late":"✅ Within SLA"}</span>;
  const ms=new Date(i.sla_deadline+"Z")-n;if(ms<0)return <b className="red">🔴 SLA BREACHED</b>;
  const f=x=>String(Math.floor(x)).padStart(2,"0");
  return <span>{f(ms/3.6e6)}:{f(ms/6e4%60)}:{f(ms/1e3%60)} remaining</span>;
}
function Msg({e}){return e?<div className="err">{e}</div>:null}

function Landing(){
  const {user}=useAuth();const [s,setS]=useState(null);
  useEffect(()=>{api("/public-stats").then(setS).catch(()=>{})},[]);
  return <main><div className="hero"><h1>FixIt+</h1><h3>Smart Campus Maintenance &amp; Resolution</h3>
    <p className="muted">Report campus problems. Track every repair. Build a better campus.</p>
    <div className="row" style={{justifyContent:"center"}}><Link className="btn p" to={user?"/report":"/login"}>Report an Issue</Link><Link className="btn" to={user?"/dashboard":"/login"}>Track My Issue</Link></div>
    <div className="flow"><span>Report</span>→<span>Analyze</span>→<span>Assign</span>→<span>Resolve</span></div>
    {s&&<div className="grid">{[["Issues reported",s.total],["Issues resolved",s.resolved],["Avg resolution (h)",s.avg_hours],["Active issues",s.active]].map(([l,v])=><div className="card stat" key={l}><b>{v}</b><span>{l}</span></div>)}</div>}
  </div></main>;
}
function Login(){
  const {setUser}=useAuth();const nav=useNavigate();
  const [email,setEmail]=useState(""),[pw,setPw]=useState(""),[e,setE]=useState(""),[busy,setBusy]=useState(false);
  const go=async(em,p)=>{setBusy(true);setE("");try{const d=await api("/login",{method:"POST",body:{email:em,password:p}});localStorage.setItem("t",d.token);localStorage.setItem("u",JSON.stringify(d.user));setUser(d.user);nav("/dashboard")}catch(x){setE(x.message)}setBusy(false)};
  return <main><div className="card form" style={{margin:"30px auto"}}><h2>Log in to FixIt+</h2><Msg e={e}/>
    <label>Email</label><input value={email} onChange={x=>setEmail(x.target.value)}/><label>Password</label><input type="password" value={pw} onChange={x=>setPw(x.target.value)}/>
    <p><button className="btn p" disabled={busy} onClick={()=>go(email,pw)}>{busy?"Logging in...":"Log in"}</button></p>
    <hr/><b>Demo mode</b> <span className="muted">(password for all: fixit123)</span>
    <div className="row" style={{marginTop:8}}>{[["Student","student@fixit.com"],["Admin","admin@fixit.com"],["Maintenance","staff@fixit.com"]].map(([n,m])=><button key={n} className="btn" disabled={busy} onClick={()=>go(m,"fixit123")}>Login as {n}</button>)}</div></div></main>;
}
function Shell({children}){
  const {user,setUser}=useAuth();const nav=useNavigate();const [open,setOpen]=useState(false);const [n,,reload]=useLoad("/notifications");
  const [dark,setDark]=useState(localStorage.getItem("theme")==="dark");
  useEffect(()=>{document.documentElement.dataset.theme=dark?"dark":"light";localStorage.setItem("theme",dark?"dark":"light")},[dark]);
  useEffect(()=>{if(!user)return;const t=setInterval(reload,15000);return()=>clearInterval(t)},[user,reload]);
  const read=async x=>{await api(`/notifications/${x.id}/read`,{method:"PUT"});reload();nav("/issue/"+x.issue_id);setOpen(false)};
  return <><nav><Link to="/" className="logo">FixIt+</Link>
    {user&&<><Link to="/dashboard">Dashboard</Link>{user.role==="student"&&<Link to="/report">Report issue</Link>}{user.role==="admin"&&<Link to="/analytics">Analytics</Link>}</>}
    <span className="sp"/><button className="btn" onClick={()=>setDark(!dark)}>{dark?"☀️":"🌙"}</button>
    {user?<><div style={{position:"relative"}}><button className="btn" onClick={()=>{setOpen(!open);reload()}}>🔔 {n?.unread>0&&<b className="red">{n.unread}</b>}</button>
      {open&&<div className="card" style={{position:"absolute",right:0,width:300,maxWidth:"85vw",maxHeight:320,overflow:"auto"}}>{n?.notifications.length?n.notifications.map(x=><div key={x.id} onClick={()=>read(x)} style={{cursor:"pointer",padding:"6px 0",fontWeight:x.is_read?400:700}}>{x.message}</div>):"No notifications yet."}</div>}</div>
      <span className="muted">{user.name} ({user.role})</span><button className="btn" onClick={()=>{localStorage.clear();setUser(null);nav("/")}}>Log out</button></>:<Link className="btn p" to="/login">Log in</Link>}
  </nav>{children}</>;
}
const Guard=({roles,children})=>{const {user}=useAuth();if(!user)return <Navigate to="/login"/>;if(roles&&!roles.includes(user.role))return <Navigate to="/dashboard"/>;return children};

function Dashboard(){
  const {user}=useAuth();const [qs,setQs]=useState({});const [staff]=useLoad(user.role==="admin"?"/staff":"/notifications");
  const qstr=new URLSearchParams(Object.fromEntries(Object.entries(qs).filter(([,v])=>v))).toString();
  const [d,e,reload]=useLoad("/issues?"+qstr);const [all]=useLoad("/issues");const [m,setM]=useState("");
  const set=k=>x=>setQs({...qs,[k]:x.target.value});
  const assign=async(id,sid)=>{if(!sid)return;setM("Assigning task...");try{await api(`/issues/${id}/assign`,{method:"POST",body:{staff_id:+sid}});setM("");reload()}catch(x){setM(x.message)}};
  const A=all?.issues||[],open=A.filter(i=>i.status!=="Resolved"),hr=3.6e6;
  const cards=user.role==="student"?[["Total reports",A.length],["Pending",A.filter(i=>["Pending","Reopened"].includes(i.status)).length],["In progress",A.filter(i=>["Assigned","In Progress"].includes(i.status)).length],["Resolved",A.filter(i=>i.status==="Resolved").length]]
   :user.role==="staff"?[["Assigned tasks",open.length],["Critical",open.filter(i=>i.priority==="CRITICAL").length],["Due soon",open.filter(i=>!i.breached&&new Date(i.sla_deadline+"Z")-Date.now()<hr).length],["Completed",A.length-open.length]]
   :[["Total issues",A.length],["Critical",open.filter(i=>i.priority==="CRITICAL").length],["Pending",A.filter(i=>["Pending","Reopened"].includes(i.status)).length],["In progress",A.filter(i=>["Assigned","In Progress"].includes(i.status)).length],["Resolved",A.length-open.length],["SLA breached",open.filter(i=>i.breached).length]];
  const crit=open.filter(i=>i.priority==="CRITICAL").slice(0,4);
  return <main><h2>Welcome back, {user.name}</h2>
    <div className="grid">{cards.map(([l,v])=><div className="card stat" key={l}><b>{v}</b><span>{l}</span></div>)}</div>
    {user.role==="admin"&&crit.length>0&&<div className="card warn"><h3>🔴 Critical issues</h3>{crit.map(i=><div key={i.id}><Link to={"/issue/"+i.id}><b>{i.ticket_id}</b></Link> {i.title} · {i.building} {i.room} · <SLA i={i}/></div>)}</div>}
    <div className="card"><h3>{user.role==="staff"?"My tasks":user.role==="student"?"My issues":"All issues"}</h3>
    <div className="filters"><input placeholder="Search ticket, title, location" value={qs.q||""} onChange={set("q")}/>
      {[["category",CATS],["priority",PRI],["status",STAT],["building",BUILDINGS]].map(([k,o])=><select key={k} value={qs[k]||""} onChange={set(k)}><option value="">{k}</option>{o.map(x=><option key={x}>{x}</option>)}</select>)}
      {user.role==="admin"&&<select value={qs.assigned_to||""} onChange={set("assigned_to")}><option value="">staff</option>{staff?.staff?.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>}
      <button className="btn" onClick={()=>setQs({})}>Clear filters</button></div>
    <Msg e={e||m}/>{!d?<p>Loading issues...</p>:d.issues.length===0?<p>{Object.keys(qs).length?"No issues match your filters.":"🎉 No maintenance issues found."}</p>:
    <div className="tw"><table><thead><tr><th>Ticket</th><th>Issue</th><th>Category</th><th>Location</th><th>Priority</th><th>Status</th><th>SLA</th><th>Assigned</th><th>Created</th></tr></thead>
    <tbody>{d.issues.map(i=><tr key={i.id}><td><Link to={"/issue/"+i.id}><b>{i.ticket_id}</b></Link></td><td>{i.title}</td><td>{ICONS[i.category]} {i.category}</td><td>{i.building} {i.room}</td><td><P p={i.priority}/></td><td><S s={i.status}/></td><td><SLA i={i}/></td>
      <td>{user.role==="admin"?<select value={i.assigned_to||""} onChange={x=>assign(i.id,x.target.value)}><option value="">Assign...</option>{staff?.staff?.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>:i.assignee||"—"}</td><td>{fd(i.created_at)}</td></tr>)}</tbody></table></div>}</div></main>;
}
function Report(){
  const nav=useNavigate();const [f,setF]=useState({category:"",title:"",description:"",building:"Block A",room:""});
  const [ai,setAi]=useState(null),[dup,setDup]=useState(null),[e,setE]=useState(""),[busy,setBusy]=useState("");
  const set=k=>x=>{setF({...f,[k]:x.target.value});setAi(null)};
  const analyze=async()=>{setE("");setBusy("MAJJAA AI is analyzing...");try{const a=await api("/ai/analyze",{method:"POST",body:f});const d=await api("/ai/duplicate-check",{method:"POST",body:f});setAi(a);setDup(d.duplicate)}catch(x){setE(x.message)}setBusy("")};
  const submit=async()=>{setBusy("Submitting...");try{const d=await api("/issues",{method:"POST",body:f});nav("/issue/"+d.id)}catch(x){setE(x.message)}setBusy("")};
  return <main><div className="card form"><h2>Report an issue</h2><Msg e={e}/>
    <label>Category (optional - AI can detect it)</label><select value={f.category} onChange={set("category")}><option value="">Let MAJJAA AI decide</option>{CATS.map(c=><option key={c}>{c}</option>)}</select>
    <label>Issue title</label><input placeholder="Ceiling fan not working" value={f.title} onChange={set("title")}/>
    <label>Description</label><textarea value={f.description} onChange={set("description")}/>
    <label>Building</label><select value={f.building} onChange={set("building")}>{BUILDINGS.map(b=><option key={b}>{b}</option>)}</select>
    <label>Room / location</label><input value={f.room} onChange={set("room")}/>
    <p className="muted">MAJJAA AI will recommend the priority.</p>
    <button className="btn p" disabled={!!busy||!f.title||!f.description} onClick={analyze}>{busy||"Analyze"}</button>
    {ai&&<div className="card" style={{marginTop:14}}><h3>MAJJAA AI analysis</h3>
      <p>{ICONS[ai.category]} <b>{ai.category}</b> ({Math.round(ai.confidence*100)}% confidence) · Severity {ai.severity}/5 · <P p={ai.priority}/> · {ai.department} · SLA {ai.sla_hours}h</p>
      <ul>{ai.reasons.map(r=><li key={r}>{r}</li>)}</ul>
      {dup&&<div className="card warn"><b>Possible duplicate issue detected.</b><p>Similarity {Math.round(dup.similarity*100)}% with <b>{dup.ticket_id}</b> ({dup.title}) - {dup.status}</p><div className="row"><button className="btn" onClick={()=>nav("/issue/"+dup.id)}>View existing issue</button></div></div>}
      <button className="btn p" disabled={!!busy} onClick={submit}>{dup?"Report anyway":"Submit issue"}</button></div>}
  </div></main>;
}
function Detail(){
  const {id}=useParams();const {user}=useAuth();const [d,e,reload]=useLoad("/issues/"+id);const [staff]=useLoad(user.role==="admin"?"/staff":"/notifications");
  const [note,setNote]=useState(""),[c,setC]=useState(""),[m,setM]=useState("");
  const act=async(fn)=>{setM("Updating...");try{await fn();setNote("");setC("");setM("");reload()}catch(x){setM(x.message)}};
  const st=(status,n)=>act(()=>api(`/issues/${id}/status`,{method:"PUT",body:{status,note:n}}));
  if(!d)return <main><Msg e={e}/>{!e&&<p>Loading issue...</p>}</main>;
  const i=d.issue,isStaff=user.role==="staff",isAdmin=user.role==="admin",mine=user.role==="student";
  const events=d.history.map(h=>[h.timestamp,h.new_status==="Pending"?"Reported":h.new_status,h.name]);
  return <main><div className="card"><div className="row"><h2>{i.ticket_id}</h2><P p={i.priority}/><S s={i.status}/></div><h3>{ICONS[i.category]} {i.title}</h3><p>{i.description}</p>
    <div className="grid" style={{fontSize:".9rem"}}>{[["Category",i.category],["Location",i.building+" "+i.room],["Reporter",i.reporter],["Assigned",i.assignee||"Not assigned"],["Created",fd(i.created_at)],["SLA deadline",fd(i.sla_deadline)]].map(([k,v])=><div key={k}><span className="muted">{k}</span><br/>{v}</div>)}</div>
    <p><b>SLA:</b> <SLA i={i}/></p><Msg e={m}/>
    <div className="card"><b>AI recommended:</b> <P p={i.ai_priority}/> (score {i.priority_score}, confidence {Math.round(i.ai_confidence*100)}%) · <b>Final admin priority:</b> <P p={i.priority}/>
      {isAdmin&&<span> <select value={i.priority} onChange={x=>act(()=>api("/issues/"+id,{method:"PUT",body:{priority:x.target.value}}))}>{PRI.map(p=><option key={p}>{p}</option>)}</select></span>}</div>
    {isAdmin&&<div className="row"><select value={i.assigned_to||""} onChange={x=>act(()=>api(`/issues/${id}/assign`,{method:"POST",body:{staff_id:+x.target.value}}))}><option value="">Assign staff...</option>{staff?.staff?.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
      <select value={i.status} onChange={x=>st(x.target.value,"Resolved set by admin")}>{STAT.map(s=><option key={s}>{s}</option>)}</select></div>}
    {isStaff&&i.status==="Assigned"&&<button className="btn p" onClick={()=>st("In Progress")}>Start work</button>}
    {isStaff&&i.status==="In Progress"&&<div><label>Resolution description (required)</label><textarea value={note} onChange={x=>setNote(x.target.value)} placeholder="Damaged socket replaced and connection tested."/><button className="btn p" onClick={()=>st("Resolved",note)}>Mark as resolved</button></div>}
    {mine&&i.status==="Resolved"&&(i.confirmed?<div className="ok">You confirmed this resolution.</div>:<div className="ok">Your issue has been marked as resolved. <div className="row" style={{marginTop:8}}><button className="btn p" onClick={()=>act(()=>api(`/issues/${id}/confirm`,{method:"POST"}))}>Confirm resolution</button><button className="btn d" onClick={()=>st("Reopened")}>Reopen issue</button></div></div>)}
  </div>
  <div className="grid" style={{alignItems:"start",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))"}}>
    <div className="card"><h3>Timeline</h3><div className="tl">{events.map((x,k)=><div key={k}><b>{x[1]}</b><br/><span className="muted">{fd(x[0])}{x[2]&&" · "+x[2]}</span></div>)}</div></div>
    <div className="card"><h3>Resolution evidence</h3>{d.evidence.length?d.evidence.map(x=><p key={x.id}>{x.description}<br/><span className="muted">{x.name} · {fd(x.uploaded_at)}</span></p>):<p className="muted">No evidence yet.</p>}
      <h3>Comments &amp; progress</h3>{d.comments.map(x=><p key={x.id}><b>{x.name}:</b> {x.comment}</p>)}
      <div className="row"><input style={{flex:1}} placeholder={isStaff?"Add progress update":"Add comment"} value={c} onChange={x=>setC(x.target.value)}/><button className="btn" onClick={()=>act(()=>api(`/issues/${id}/comments`,{method:"POST",body:{comment:c}}))}>Post</button></div></div></div></main>;
}
const Bars=({data,color})=>{const mx=Math.max(1,...Object.values(data));return Object.entries(data).map(([k,v])=><div className="bar" key={k}><em>{k}</em><i style={{width:(v/mx*100)+"%",minWidth:4,background:color?.[k]}}/> {v}</div>)};
function Analytics(){
  const [d,e]=useLoad("/analytics");if(!d)return <main><Msg e={e}/>{!e&&<p>Loading analytics...</p>}</main>;
  const s=d.summary,pc={CRITICAL:"var(--CRITICAL)",HIGH:"var(--HIGH)",MEDIUM:"var(--MEDIUM)",LOW:"var(--LOW)"};
  return <main><h2>Analytics</h2><div className="grid">{[["Resolution rate",s.resolution_rate+"%"],["Avg resolution",s.avg_hours+" h"],["SLA compliance",s.sla_compliance+"%"],["SLA breached (open)",s.breached]].map(([l,v])=><div className="card stat" key={l}><b>{v}</b><span>{l}</span></div>)}</div>
  <div className="card"><h3>MAJJAA Insights</h3><ul>{d.insights.map(x=><li key={x}>{x}</li>)}</ul></div>
  <div className="grid" style={{gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))"}}>
    <div className="card"><h3>Issues by category</h3><Bars data={d.categories}/></div><div className="card"><h3>Issues by priority</h3><Bars data={d.priorities} color={pc}/></div>
    <div className="card"><h3>Issues by status</h3><Bars data={d.statuses}/></div><div className="card"><h3>Reported over time</h3><Bars data={d.trends}/></div></div>
  <h3>Campus hotspots</h3><div className="grid">{Object.entries(d.buildings).map(([b,x])=><div key={b} className={"card hot "+(x.total>=12?"h":x.total>=7?"m":"")}><b>{b}</b><br/>{x.total} issues · {x.critical} critical<br/><span className="muted">Top: {x.top_category} · Avg fix {x.avg_hours} h</span></div>)}</div>
  <div className="card tw"><h3>Maintenance performance</h3><table><thead><tr><th>Team</th><th>Assigned</th><th>Completed</th><th>Open</th><th>Avg time (h)</th><th>SLA</th></tr></thead><tbody>{d.staff.map(x=><tr key={x.name}><td>{x.name}</td><td>{x.assigned}</td><td>{x.completed}</td><td>{x.open}</td><td>{x.avg_hours}</td><td>{x.sla==null?"—":x.sla+"%"}</td></tr>)}</tbody></table></div></main>;
}
export default function App(){
  const [user,setUser]=useState(()=>{try{return JSON.parse(localStorage.getItem("u"))}catch{return null}});
  return <Auth.Provider value={{user,setUser}}><BrowserRouter><Shell><Routes>
    <Route path="/" element={<Landing/>}/><Route path="/login" element={<Login/>}/>
    <Route path="/dashboard" element={<Guard><Dashboard/></Guard>}/><Route path="/report" element={<Guard roles={["student"]}><Report/></Guard>}/>
    <Route path="/issue/:id" element={<Guard><Detail/></Guard>}/><Route path="/analytics" element={<Guard roles={["admin"]}><Analytics/></Guard>}/>
  </Routes></Shell></BrowserRouter></Auth.Provider>;
}
